#include <cs50.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>


int main()
{
    int result;
    char choice1;
    char choice2;
    char choice3;
        
    printf("Which cipher method do you wish to use? Possible choice are: \nN:Caesar's Cipher \nV:Vigenère’s Cipher\n");   
    choice1 = GetChar();
    switch(choice1)
    {
        case 'N':
        printf("You have selected Caesar's Cipher\n");
        printf("Please type the word/sentence you wish to encrypt or decrypt\n");
        string Input = GetString();
        int Length = strlen(Input);
        printf("Please indicate whether you want to Encrypt, by typing E, or Decrypt, by typing D\n");
        choice2 = GetChar();
        switch(choice2)
        {
        case 'E':
        printf("Please give an encryption value\n");
        int EncrypRule = GetInt();
        for (int i = 0; i < Length; i++)
             {
                 char letter = Input[i];
                 if (isupper(letter))
                    {
                        result = (((letter - 65) + EncrypRule) % 26 + 65);
                    }
                 else if (islower(letter))
                    {
                        result = (((letter - 97) + EncrypRule) % 26 + 97);
                    }   
                 else
                    {
                        result = letter;
                    } 
             printf("%c", result);
            }
            printf("\n");
        break;

        case 'D':
        printf("How many iterations do you want the decryption to run for?\n");
        int DecrypRule = GetInt();
        for (int p = 1; p <= DecrypRule; p++) 
        {
            for (int i = 0; i < Length; i++)
                  {
                char letter = Input[i];
                if (isupper(letter))
                     {
                    result = (((letter + 65) - p) % 26 + 65);
                     }
                else if (islower(letter))
                     {
                    result = ((letter - 71 - p) % 26 + 97);
                     }
                else
                     {
                    result = letter;
                     }
             printf("%c", result);
            }
            printf(" DECRYPTION VALUE %i\n", p);
        }
        break;
        default: 
         printf("ur an idiot\n" );
     }
        break;
     
        case 'V':
        printf("You have selected Vigenère's Cipher\n");
        printf("Please type the word/sentence you wish to encrypt or decrypt\n");
        Input = GetString();
        Length = strlen(Input);
        printf("Please indicate whether you want to Encrypt, by typing E, or Decrypt, by typing D\n");
        choice3 = GetChar();
        switch(choice3)
        {
            case 'E':
          {    
            printf("Please enter an encoding word\n");
            string EncryptValue = GetString();
            int p = 0;
            do
            {
            for (int i = 0 ; i <= strlen(EncryptValue)-1; i++)
             {
              if (i == strlen(EncryptValue))
              {
                  i = 0;
              }
              char seed = EncryptValue[i];
              if(isupper(seed))
              {
                seed = ((seed-97)+26)%26;
              }
              
              if(islower(seed))
              {
                seed = ((seed-65)+26)%26;
              }
              
              if (islower(Input[p]))
              {
                result = (((Input[p] - 71 - p) + seed) % 26 + 65);
              }
                
              else if (isupper(Input[p]))
              {
                result = (((Input[p] - 65 - p) + seed) % 26 + 65);
              }
              else 
              {
                result = Input[p];
              }
               p++;
               printf("%c", result);
             }
            }
            while (p < strlen(Input));
        
          }
           printf("\n");    
            break;
            
            default:
            printf ("HELP\n");
          }
        
    
        }
        
    }

